// Smoke me up

var x = "/you have smoked weed";
var y = "/game over - Thank You For Playing :  -  )";
function smoke() {
 document.getElementById("print").innerHTML = x;
 document.getElementById("print2").innerHTML = y;
}